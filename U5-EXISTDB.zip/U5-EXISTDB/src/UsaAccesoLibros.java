
public class UsaAccesoLibros {

	public static void main(String[] args) {
		AccesoLibros a = new AccesoLibros();
		a.conectar();
		//a.consultarTitulos();
		
		//a.consultar2();
		a.consultarTituloAutor();
		a.desconectar();
	}

}
