import org.xmldb.api.DatabaseManager;

import java.util.Scanner;

import org.xmldb.api.*;
import org.xmldb.api.base.*;
import org.xmldb.api.modules.*;

public class AccesoMenu {

	private Collection col = null;
	private XPathQueryService servicio;
	
	public void conectar() {
		String driver = "org.exist.xmldb.DatabaseImpl";
		col = null;

// String uri=&quot;xmldb:exist://192.168.1.16:8080/exist/xmlrpc/db&quot;;//ip TAMBIÉN FUNCIONA
// String uri=&quot;xmldb:exist://embedded-eXist-server&quot;; //si tenemos la bdd
// embebida
		String uri = "xmldb:exist://localhost:8090/exist/xmlrpc/db";
		String user = "admin";
		String pass = "1234";
		try {
//NOS CONECTAMOS
			Class cl = Class.forName(driver);
			System.out.println("Driver encontrado para " + driver);
			Database db = (Database) cl.newInstance();
			System.out.println("Db instancia creada");
			DatabaseManager.registerDatabase(db);
			System.out.println("BDD registrada");
// nos conectamos con el método getCollection
// LA VARIABLE COL ESTÁ &quot;ASIGNADA&quot; Y LA PUEDEN USAR EL RESTO DE MÉTODOS
			col = DatabaseManager.getCollection(uri, user, pass);
			System.out.println("Conectados a la bdd " + uri);
//COMPROBAMOS SI LA CONEXIÓN TIENE RECURSOS (ARCHIVOS O COLECCIONES)
			if (col == null) {
				System.out.println("---colección no encontrada ---");
			} else {
				System.out.println("Nº de recursos de la colección:" +

						col.getResourceCount());

				System.out.println("Primer recurso:" + col.listResources()[0]);// muestra el primer recurso

//podríamos hacer un bucle para mostrar todos los recursos
//desde i=0 hasta col.getResourceCount()
			}
//OBTENEMOS EL SERVICIO Y LE ASIGNAMOS VALOR
			servicio = (XPathQueryService) col.getService("XPathQueryService", "1.0");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void desconectar() {
		try {
			col.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void consultarMenus() {
	    try {
	        // Adjust the XQuery query to target the <menu> elements
	        ResourceSet result = servicio.query("for $m in //menu return $m");

	        // Output the number of results
	        System.out.println("Numero de resultados:" + result.getSize());

	        // Iterate over the results and print each menu
	        ResourceIterator it = result.getIterator();
	        while (it.hasMoreResources()) {
	            Resource r = (Resource) it.nextResource();
	            System.out.println((String) r.getContent());
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
	
	public void insertarMenu() {
	    try {
	        // Ask the user if they want to insert a menu
	        System.out.println("Do you want to insert a menu item? (yes/no)");
	        Scanner scanner = new Scanner(System.in);
	        String response = scanner.nextLine().trim().toLowerCase();

	        if (response.equals("yes")) {
	            // Ask for menu item details
	            System.out.println("Enter the name of the menu item:");
	            String itemName = scanner.nextLine().trim();

	            System.out.println("Enter the price of the menu item:");
	            double itemPrice = Double.parseDouble(scanner.nextLine().trim());

	            // Prepare the XQuery for inserting the menu item
	            String xquery = String.format(
	                "update insert " +
	                "<item>" +
	                "   <name>%s</name>" +
	                "   <price>%s</price>" +
	                "</item> into /menu",
	                itemName,
	                itemPrice
	            );

	            // Execute the XQuery to insert the menu item
	            servicio.query(xquery);

	            System.out.println("Menu item inserted successfully.");
	        } else {
	            System.out.println("No menu item inserted.");
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
}
