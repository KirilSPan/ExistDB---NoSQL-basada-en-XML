
public class UsaAccesoMenu {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AccesoMenu m = new AccesoMenu();
		m.conectar();

		m.consultarMenus();
		//m.insertarMenu();
		m.consultarMenus();
		m.desconectar();
		
	}

}
